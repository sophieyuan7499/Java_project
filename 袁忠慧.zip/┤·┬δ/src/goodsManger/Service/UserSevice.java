package goodsManger.Service;

import goodsManger.model.User;

public interface UserSevice {
public User  login(String account,String psw);
}
