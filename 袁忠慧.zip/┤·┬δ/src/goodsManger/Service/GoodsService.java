package goodsManger.Service;

public interface GoodsService {
public void addGoods();
}
