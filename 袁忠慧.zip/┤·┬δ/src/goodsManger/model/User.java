package goodsManger.model;

public class User {
private int Id;
private String name;
private String account;
private String password;

public int getId() {
	return Id;
}
public void setId(int id) {
	this.Id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAccount() {
	return account;
}
public void setAccount(String account) {
	this.account = account;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

	
}
