package goodsManger.Dao;

import goodsManger.model.Goods;

public interface goodsDao {
public void addGoods( Goods goods);

}
